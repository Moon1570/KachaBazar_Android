package com.example.ecommerce;

public class Category {

    private String categoryName, categoryDesc, categoryImage;

    public Category(String categoryName, String categoryDesc, String categoryImage) {
        this.setCategoryName(categoryName);
        this.setCategoryDesc(categoryDesc);
        this.setCategoryImage(categoryImage);
    }


    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public String getCategoryDesc() {
        return categoryDesc;
    }

    public void setCategoryDesc(String categoryDesc) {
        this.categoryDesc = categoryDesc;
    }

    public String getCategoryImage() {
        return categoryImage;
    }

    public void setCategoryImage(String categoryImage) {
        this.categoryImage = categoryImage;
    }
}
