package com.example.ecommerce;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.drawerlayout.widget.DrawerLayout;

import com.example.ecommerce.config.IpConfig;
import com.google.android.material.navigation.NavigationView;
import com.squareup.picasso.Picasso;

import org.json.JSONException;
import org.json.JSONObject;

public class ViewSellerProductActivity extends AppCompatActivity {


    TextView name, price, desc, seller, govtPrice;
    ImageView imageView;
    Button button;
    String cid, product, pid, pp;
    private DrawerLayout drawerLayout;
    private NavigationView navigationView;
    IpConfig ipConfig = new IpConfig();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_seller_product);



        name = findViewById(R.id.view_seller_product_name);
        price = findViewById(R.id.view_seller_product_price);
        desc = findViewById(R.id.view_seller_product_description);
        imageView =findViewById(R.id.view_seller_product_image);
        seller = findViewById(R.id.view_seller_name);
        govtPrice = findViewById(R.id.view_seller_product_govt_price);

        button = findViewById(R.id.btn_buy_from_seller);

        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = this.getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
            window.setStatusBarColor(this.getResources().getColor(R.color.foreground));

        }

        drawerLayout = findViewById(R.id.drawer_layout);
        navigationView = findViewById(R.id.nav_view);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        navigationView.setItemIconTintList(null);


        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();


        final Intent intent = getIntent();
        product = intent.getExtras().getString("product");

        

        try {
            final JSONObject jsonObject = new JSONObject(product);
            name.setText(jsonObject.getString("productName"));
            desc.setText(jsonObject.getString("productDescription"));
            seller.setText("By " + jsonObject.getString("sellerName"));
            govtPrice.setText("Government Price : " + jsonObject.getString("govtPrice") + " /=");
            price.setText("Price " + jsonObject.getString("productPrice") + " /=");

            pp = jsonObject.getString("productPrice");

            pid = jsonObject.getString("productId");
            Picasso.get().load(ipConfig.myURI + "images/sellerproducts/"+ jsonObject.getString("productImageName")).into(imageView);

        } catch (JSONException e) {
            e.printStackTrace();
        }

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1 = new Intent(ViewSellerProductActivity.this,BuySellerProductActivity.class);
                intent1.putExtra("pid", pid);
                intent1.putExtra("product", product);
                intent1.putExtra("pp", pp);
                startActivity(intent1);
            }
        });

        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                Intent intent1;
                if (menuItem.getTitle().equals("Shop")){
                    intent1 = new Intent(ViewSellerProductActivity.this, MainActivity.class);
                    startActivity(intent1);
                }
                else if (menuItem.getTitle().equals("Seller Market"))
                {
                    intent1 = new Intent(ViewSellerProductActivity.this, SellerActivity.class);
                    startActivity(intent1);
                }
                else if (menuItem.getTitle().equals("Local Market"))
                {
                    intent1 = new Intent(ViewSellerProductActivity.this, LocalActivity.class);
                    startActivity(intent1);
                }
                else if (menuItem.getTitle().equals("Search Market"))
                {
                    intent1 = new Intent(ViewSellerProductActivity.this, SearchActivity.class);
                    startActivity(intent1);
                }
                else if (menuItem.getTitle().equals("Profile"))
                {
                    intent1 = new Intent(ViewSellerProductActivity.this, ProfileActivity.class);
                    startActivity(intent1);
                }
                else if (menuItem.getTitle().equals("Login"))
                {
                    intent1 = new Intent(ViewSellerProductActivity.this, LoginActivity.class);
                    startActivity(intent1);
                }
                else if (menuItem.getTitle().equals("Browse All")){
                    intent1 = new Intent(ViewSellerProductActivity.this, BrowseAllActivity.class);
                    startActivity(intent1);
                }
                return true;
            }
        });

    }
}
