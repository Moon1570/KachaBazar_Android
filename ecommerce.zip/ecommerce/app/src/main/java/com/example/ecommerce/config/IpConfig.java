package com.example.ecommerce.config;

public class IpConfig {
    public String myURI = "http://10.10.22.183:9090/ecommerce/";
}
