package com.example.ecommerce;

public class Product {
    private String name, price, govtPrice, image;

    public Product(String name, String price, String govtPrice, String image) {
        this.setName(name);
        this.setGovtPrice(govtPrice);
        this.setPrice(price);
        this.setImage(image);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getGovtPrice() {
        return govtPrice;
    }

    public void setGovtPrice(String description) {
        this.govtPrice = description;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }
}
