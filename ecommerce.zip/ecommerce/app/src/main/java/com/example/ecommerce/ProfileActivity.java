package com.example.ecommerce;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.drawerlayout.widget.DrawerLayout;

import com.example.ecommerce.config.IpConfig;
import com.google.android.material.navigation.NavigationView;
import com.squareup.picasso.Picasso;

import org.json.JSONException;
import org.json.JSONObject;

import de.hdodenhof.circleimageview.CircleImageView;

public class ProfileActivity extends AppCompatActivity {

    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;
    MenuItem menuItem1;
    Menu menu;
    public static final String mypreference = "mypref";
    public static final String login = "logout";
    public static final String cid = "null";
    String check;

    private DrawerLayout drawerLayout;
    private NavigationView navigationView;
    private CircleImageView circleImageView;
    private TextView name, phone, division, district;

    IpConfig ipConfig = new IpConfig();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        sharedPreferences = getSharedPreferences(mypreference,
                Context.MODE_PRIVATE);
        editor = sharedPreferences.edit();


        if (sharedPreferences.getString("login", null) == null)
        {
            Intent intent = new Intent(ProfileActivity.this, LoginActivity.class);
            startActivity(intent);
        }
        else {

            if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                Window window = this.getWindow();
                window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
                window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
                window.setStatusBarColor(this.getResources().getColor(R.color.foreground));

            }

            drawerLayout = findViewById(R.id.drawer_layout);
            navigationView = findViewById(R.id.nav_view);

            name = findViewById(R.id.profile_Name);
            phone = findViewById(R.id.profile_phone);
            division = findViewById(R.id.profile_division);
            district = findViewById(R.id.profile_district);


            menu = navigationView.getMenu();
            menuItem1 = menu.findItem(R.id.nav_login);
            if (sharedPreferences.getString("login", null) ==null)
            {
                ///Do Nothing
            }
            else {
                menuItem1.setTitle("Logout");
            }


            Toolbar toolbar = findViewById(R.id.toolbar);
            setSupportActionBar(toolbar);
            circleImageView = findViewById(R.id.profile_picture);

            navigationView.setItemIconTintList(null);


            ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
            drawerLayout.addDrawerListener(toggle);
            toggle.syncState();







            String customer = sharedPreferences.getString("cid", null);
            try {
                JSONObject jsonObject = new JSONObject(customer);
                Picasso.get().load(ipConfig.myURI + "images/customers/"+ jsonObject.getString("customerImageName")).into(circleImageView);
                name.setText(jsonObject.getString("customerFirstName") + " " + jsonObject.getString("customerLastName"));
                phone.setText(jsonObject.getString("customerPhone"));

                String area = jsonObject.getString("divisionmodel");
                JSONObject jsonObject1 = new JSONObject(area);
                division.setText(jsonObject1.getString("divisionName"));

                area = jsonObject.getString("districtModel");
                jsonObject1 = new JSONObject(area);
                district.setText(jsonObject1.getString("districtName"));


            } catch (JSONException e) {
                e.printStackTrace();
            }






            menu = navigationView.getMenu();
            menuItem1 = menu.findItem(R.id.nav_login);

            if (sharedPreferences.getString("login", null) == "login")
            {
                menuItem1.setTitle("Logout");
            }





            navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
                @Override
                public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                    Intent intent1;
                    if (menuItem.getTitle().equals("Shop")) {
                        intent1 = new Intent(ProfileActivity.this, MainActivity.class);
                        startActivity(intent1);
                    } else if (menuItem.getTitle().equals("Seller Market")) {
                        intent1 = new Intent(ProfileActivity.this, SellerActivity.class);
                        startActivity(intent1);
                    } else if (menuItem.getTitle().equals("Local Market")) {
                        intent1 = new Intent(ProfileActivity.this, LocalActivity.class);
                        startActivity(intent1);
                    } else if (menuItem.getTitle().equals("Search Market")) {
                        intent1 = new Intent(ProfileActivity.this, SearchActivity.class);
                        startActivity(intent1);
                    } else if (menuItem.getTitle().equals("Profile")) {
                        intent1 = new Intent(ProfileActivity.this, ProfileActivity.class);
                        startActivity(intent1);
                    } else if (menuItem.getTitle().equals("Login")) {
                        intent1 = new Intent(ProfileActivity.this, LoginActivity.class);
                        startActivity(intent1);
                    }
                    else if (menuItem.getTitle().equals("Logout")) {
                        editor.clear();
                        editor.commit();
                        intent1 = new Intent(ProfileActivity.this, MainActivity.class);
                        startActivity(intent1);
                    }
                    else if (menuItem.getTitle().equals("Browse All")){
                        intent1 = new Intent(ProfileActivity.this, BrowseAllActivity.class);
                        startActivity(intent1);
                    }
                    return true;
                }
            });
        }


    }
}
