package com.example.ecommerce;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.drawerlayout.widget.DrawerLayout;

import com.example.ecommerce.config.IpConfig;
import com.google.android.material.navigation.NavigationView;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.JsonHttpResponseHandler;
import com.loopj.android.http.RequestParams;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import cz.msebera.android.httpclient.Header;

public class ViewProductActivity extends AppCompatActivity {




    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;
    MenuItem menuItem1;
    Menu menu;
    public static final String mypreference = "mypref";
    String check;

    RequestParams params;
    AsyncHttpClient client;

    TextView name, price, desc;
    ImageView imageView;
    Button button;
    String cid, product, pid;
    private DrawerLayout drawerLayout;
    private NavigationView navigationView;
    IpConfig ipConfig = new IpConfig();
    EditText cartQty;
    Button btnCart;


    String MYURL = ipConfig.myURI + "restcart";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_product);

        sharedPreferences = getSharedPreferences(mypreference,
                Context.MODE_PRIVATE);
        editor = sharedPreferences.edit();

        name = findViewById(R.id.view_product_name);
        price = findViewById(R.id.view_product_price);
        desc = findViewById(R.id.view_product_description);
        imageView =findViewById(R.id.view_product_image);
        button = findViewById(R.id.btn_buy_from_inventory);
        cartQty = findViewById(R.id.add_cart_qty);
        btnCart = findViewById(R.id.btn_add_to_cart);

        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = this.getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
            window.setStatusBarColor(this.getResources().getColor(R.color.foreground));

        }

        drawerLayout = findViewById(R.id.drawer_layout);
        navigationView = findViewById(R.id.nav_view);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        navigationView.setItemIconTintList(null);


        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();


        final Intent intent = getIntent();
        product = intent.getExtras().getString("product");

        try {
            final JSONObject jsonObject = new JSONObject(product);
            name.setText(jsonObject.getString("productName"));
            desc.setText(jsonObject.getString("productDescription"));
            price.setText(jsonObject.getString("productPrice"));
            pid = jsonObject.getString("productId");
            Picasso.get().load(ipConfig.myURI + "images/products/"+ jsonObject.getString("productImageName")).into(imageView);

            button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent1 = new Intent(ViewProductActivity.this,BuyActivity.class);
                    try {
                        intent1.putExtra("price", jsonObject.getString("productPrice"));
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    intent1.putExtra("pid", pid);
                    intent1.putExtra("product", product);
                    startActivity(intent1);
                }
            });

            btnCart.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String qty = cartQty.getText().toString();
                    if (qty.isEmpty()){
                        Toast.makeText(ViewProductActivity.this, "Please insert the quantity", Toast.LENGTH_SHORT).show();
                    }else if (sharedPreferences.getString("login", null) == null)
                    {
                        Intent intent = new Intent(ViewProductActivity.this, LoginActivity.class);
                        startActivity(intent);
                    }else {
                        String id = sharedPreferences.getString("id", null);

                        client = new AsyncHttpClient();
                        params  = new RequestParams();

                        params.put("cid", id);
                        params.put("pid", pid);
                        params.put("qty", qty);
                        params.put("action", "cartadd");

                        client.post(MYURL, params, new JsonHttpResponseHandler(){

                            @Override
                            public void onSuccess(int statusCode, Header[] headers, JSONArray response) {
                                super.onSuccess(statusCode, headers, response);
                                Toast.makeText(ViewProductActivity.this, "Added to cart", Toast.LENGTH_SHORT).show();
                                Intent intent1 = new Intent(ViewProductActivity.this, MainActivity.class);
                                startActivity(intent1);

                            }

                            @Override
                            public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                                super.onFailure(statusCode, headers, responseString, throwable);
                            }
                        });
                    }
                }
            });


        } catch (JSONException e) {
            e.printStackTrace();
        }




        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                Intent intent1;
                if (menuItem.getTitle().equals("Shop")){
                    intent1 = new Intent(ViewProductActivity.this, MainActivity.class);
                    startActivity(intent1);
                }
                else if (menuItem.getTitle().equals("Seller Market"))
                {
                    intent1 = new Intent(ViewProductActivity.this, SellerActivity.class);
                    startActivity(intent1);
                }
                else if (menuItem.getTitle().equals("Local Market"))
                {
                    intent1 = new Intent(ViewProductActivity.this, LocalActivity.class);
                    startActivity(intent1);
                }
                else if (menuItem.getTitle().equals("Search Market"))
                {
                    intent1 = new Intent(ViewProductActivity.this, SearchActivity.class);
                    startActivity(intent1);
                }
                else if (menuItem.getTitle().equals("Profile"))
                {
                    intent1 = new Intent(ViewProductActivity.this, ProfileActivity.class);
                    startActivity(intent1);
                }
                else if (menuItem.getTitle().equals("Login"))
                {
                    intent1 = new Intent(ViewProductActivity.this, LoginActivity.class);
                    startActivity(intent1);
                }
                else if (menuItem.getTitle().equals("Browse All")){
                    intent1 = new Intent(ViewProductActivity.this, BrowseAllActivity.class);
                    startActivity(intent1);
                }
                return true;
            }
        });
    }
}
