package com.example.ecommerce;

public class SellerProduct {
    private String name, price, image, sellerName;

    public SellerProduct(String name, String price, String image, String sellerName) {
        this.name = name;
        this.price = price;
        this.image = image;
        this.sellerName = sellerName;
    }

    public SellerProduct() {

    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getSellerName() {
        return sellerName;
    }

    public void setSellerName(String sellerName) {
        this.sellerName = sellerName;
    }
}
